﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class Employee
    {
        public int id { get; set; }
        public string clientID { get; set; }
        public virtual string PayeeType { get; set; }
        public virtual string TFN { get; set; }
        public virtual string Surname { get; set; }
        public virtual string GivenName { get; set; }
        public virtual string OtherName { get; set; }
        public virtual string AlternateName { get; set; }
        public virtual DateTime DOB { get; set; }
        public virtual string Gender { get; set; }
        public virtual string AddressLine1 { get; set; }
        public virtual string AddressLine2 { get; set; }
        public virtual string Loaclity { get; set; }
        public virtual string State { get; set; }
        public virtual string Pcode { get; set; }
        public virtual string Country { get; set; }
        public virtual string DateHired { get; set; }
        public virtual string EmploymentType { get; set; }
        public virtual Boolean AustralianResident { get; set; }
        public virtual Boolean TaxFreeThreshold { get; set; }
        public virtual Boolean SeniorsPensionersTaxOffset { get; set; }
        public virtual Boolean TaxOffset { get; set; }
        public virtual Boolean HigherEducationLoanProgram { get; set; }
        public virtual Boolean FinancialSupplementDebt { get; set; }
        public virtual string AdditionalTax { get; set; }
        public virtual Boolean Spouse { get; set; }
        public virtual int DependentChildren { get; set; }
        public virtual string MedicareLevySurchargeIncrease { get; set; }
        public virtual string MedicareLevyExemption { get; set; }
        public virtual string Phone { get; set; }
        public virtual string Mobile { get; set; }
        public virtual string Email { get; set; }
        public virtual string Award { get; set; }
        public virtual string Classification { get; set; }
        public virtual string SpecialRate { get; set; }
        public virtual string AnnualLeaveWeeks { get; set; }
        public virtual string PersonalLeaveDays { get; set; }
        public virtual string LongServiceLeaveYears { get; set; }
        public virtual string LongServiceLeaveWeeks { get; set; }
        public virtual int SuperannuationFund { get; set; }
        public virtual string Superannuation { get; set; }
        public virtual string NoPaymentIfLessThan { get; set; }
        public virtual string NoPaymentLessThanAge { get; set; }
        public virtual string PaymentMethod { get; set; }
        public virtual string BankingPriorityNo { get; set; }
        public virtual string AmountType { get; set; }
        public virtual string BSB { get; set; }
        public virtual string AccountNo { get; set; }
        public virtual string Type { get; set; }
        public virtual string AccountName { get; set; }
        public virtual string Reference { get; set; }
        public virtual string PrimaryEmergencyContactName { get; set; }
        public virtual string PrimaryEmergencyContactRelationship { get; set; }
        public virtual string PrimaryEmergencyContactPhone1 { get; set; }
        public virtual string PrimaryEmergencyContactPhone2 { get; set; }
        public virtual string SecondaryEmergencyContactName { get; set; }
        public virtual string SecondaryEmergencyContactRelationship { get; set; }
        public virtual string SecondaryEmergencyContactPhone1 { get; set; }
        public virtual string SecondaryEmergencyContactPhone2 { get; set; }
    }
}
