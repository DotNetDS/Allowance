﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class Superannuation
    {
        public int id { get; set; }
        public string clientID { get; set; }
        public virtual string FundName { get; set; }
        public virtual int ABN { get; set; }
        public virtual int USI { get; set; }
        public virtual string ElectronicServiceAddress { get; set; }
        public virtual string FundPaid { get; set; }
        public virtual DateTime PeriodStartDate { get; set; }
        public virtual string PaymentMethod { get; set; }
        public virtual string PaymentRefNo { get; set; }
        public virtual int BPAYBillerCode { get; set; }
        public virtual int BSB { get; set; }
        public virtual int AccountNumber { get; set; }
        public virtual string AccountName { get; set; }
        public virtual string FinancialInstitution { get; set; }
    }
}
