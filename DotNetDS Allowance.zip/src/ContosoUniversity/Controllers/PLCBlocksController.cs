using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ContosoUniversity.Data;
using ContosoUniversity.Models;

namespace ContosoUniversity.Controllers
{
    public class PLCBlocksController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PLCBlocksController(ApplicationDbContext context)
        {
            _context = context;    
        }

        // GET: PLCBlocks
        public async Task<IActionResult> Index(string sortOrder,string currentFilter,string searchString,int? page)
        {
            ViewData["CurrentSort"] = sortOrder;

            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;

            var plcblocks = from s in _context.PLCBlock
                         where s.clientID == User.Identity.Name
                         select s;

            //var plcblocks = from s in _context.PLCBlock
            //               select s;

            if (!String.IsNullOrEmpty(searchString))
            {
                plcblocks = plcblocks.Where(s => s.BlockType.Contains(searchString));
                                       /*|| s.Number.Contains(searchString));*/
            }

            switch (sortOrder)
            {
                case "name_desc":
                    plcblocks = plcblocks.OrderByDescending(s => s.BlockType);
                    break;
                case "Date":
                    plcblocks = plcblocks.OrderBy(s => s.Number);
                    break;
                case "date_desc":
                    plcblocks = plcblocks.OrderByDescending(s => s.Description);
                    break;
                default:
                    plcblocks = plcblocks.OrderBy(s => s.BlockType);
                    break;
            }
            int pageSize = 3;
            return View(await PaginatedList<PLCBlock>.CreateAsync(plcblocks.AsNoTracking(), page ?? 1, pageSize));
        }

        // GET: PLCBlocks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plcblock = await _context.PLCBlock.Include(cc=>cc.BlockType).Include(s => s.Number).Include(s => s.Description)
            .AsNoTracking()
            .SingleOrDefaultAsync(m => m.id == id);
            if (plcblock == null)
            {
                return NotFound();
            }

            return View(plcblock);
        }

        // GET: PLCBlocks/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PLClocks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BlockType,Number,Description")] PLCBlock plcblock)
        {
            try { 
            if (ModelState.IsValid)
            {
                _context.Add(plcblock);

                    plcblock.clientID = User.Identity.Name;
                    
                    await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            }
            catch
             (DbUpdateException  ex )
            {
                //Log the error (uncomment ex variable name and write a log.
                ModelState.AddModelError("", "Unable to save changes. " +
                    "Try again, and if the problem persists " +
                    "see your system administrator.");
            }

            return View(plcblock);
        }
       
       

        // GET: PLCBlocks/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plcblockToUpdate = await _context.PLCBlock.SingleOrDefaultAsync(m => m.id == id);
            //if (await TryUpdateModelAsync<PLCBlock>(
            //     plcblockToUpdate,
            //     "",
            //     s => s.FirstMidName, s => s.LastName, s => s.EnrollmentDate))
            //{
            //    try
            //    {
            //        await _context.SaveChangesAsync();
            //        return RedirectToAction("Index");
            //    }
            //    catch (DbUpdateException /* ex */)
            //    {
            //        //Log the error (uncomment ex variable name and write a log.)
            //        ModelState.AddModelError("", "Unable to save changes. " +
            //            "Try again, and if the problem persists, " +
            //            "see your system administrator.");
            //    }
            //}
            return View(plcblockToUpdate);

        }

        // POST: PLCBlocks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,BlockType,Number,Description")] PLCBlock plcblock)
        {
            if (id != plcblock.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(plcblock);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PLCBlockExists(plcblock.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index");
            }
            return View(plcblock);
        }

        // GET: PLCBlocks/Delete/5
        public async Task<IActionResult> Delete(int? id, bool? saveChangesError = false)
        {

           
                if (id == null)
            {
                return NotFound();
            }

            var plcblock = await _context.PLCBlock.AsNoTracking().SingleOrDefaultAsync(m => m.id == id);
            if (plcblock == null)
            {
                return NotFound();
            }
            if (saveChangesError.GetValueOrDefault())
            {
                ViewData["ErrorMessage"] =
                    "Delete failed. Try again, and if the problem persists " +
                    "see your system administrator.";
            }



            return View(plcblock);
        }

        // POST: PLCBlocks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var plcblock = await _context.PLCBlock.AsNoTracking()
.SingleOrDefaultAsync(m => m.id == id);
            if (plcblock == null)
            {
                return RedirectToAction("Index");
            }

            try
            {

                _context.PLCBlock.Remove(plcblock);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            catch (DbUpdateException /* ex */)
            {
                //Log the error (uncomment ex variable name and write a log.)
                return RedirectToAction("Delete", new { id = id, saveChangesError = true });
            }

        }

        private bool PLCBlockExists(int id)
        {
            return _context.PLCBlock.Any(e => e.id == id);
        }


        // GET: PLCBlocks/Generate
        public IActionResult Generate()
        {
            return View();
        }

        // POST: PLClocks/Generate
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Generate([Bind("BlockType,Number,Description")] PLCBlock plcblock)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(plcblock);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            catch
             (DbUpdateException ex)
            {
                //Log the error (uncomment ex variable name and write a log.
                ModelState.AddModelError("", "Unable to save changes. " +
                    "Try again, and if the problem persists " +
                    "see your system administrator.");
            }

            return View(plcblock);
        }


    }
}
