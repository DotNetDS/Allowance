using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ContosoUniversity.Data;
using ContosoUniversity.Models;
using System.IO;

namespace ContosoUniversity.Controllers
{
    public class AllowanceController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AllowanceController(ApplicationDbContext context)
        {
            _context = context;

            

        }

        // GET: Allowance
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewData["CurrentSort"] = sortOrder;

            ViewData["UsedAllowanceIDSortParm"] = String.IsNullOrEmpty(sortOrder) ? "UsedAllowanceID" : "";
            //ViewData["DateTimeSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;


            var allowances = from s in _context.Allowance
                         //where s.ClientId == User.Identity.Name
                             where s.AllowanceType != null

                             select s;


            //var values = from s in _context.Allowance
            //               select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                allowances = allowances.Where(s => s.id != 0);
            }

            switch (sortOrder)
            {
                case "UsedAllowanceID":
                    allowances = allowances.OrderBy(s => s.AllowanceType);
                    break;
                //case "Value":
                //    values = values.OrderByDescending(s => s.Value);
                //    break;
                //default:
                //    //values = values.OrderBy(s => s.ID);
                //    values = values.OrderBy(s => s.DateTime);
                //    break;
            }
            int pageSize = 3;
            return View(await PaginatedList<Allowance>.CreateAsync(allowances.AsNoTracking(), page ?? 1, pageSize));
        }

        // GET: Allowance/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Allowance = await _context.Allowance.Include(cc => cc.UsedAllowanceID).
            AsNoTracking()
            .SingleOrDefaultAsync(m => m.id == id);
            if (Allowance == null)
            {
                return NotFound();
            }

            return View(Allowance);
        }

        // GET: Allowance/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Allowance/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id,UsedAllowanceID,AllowanceType,Description,PaidBy,Amount,Taxable,W1,PayrollTax,OTE,SGRule,SpecialSuperRule,SpecialSuperRate")] Allowance allowance)

        //public async Task<IActionResult> Create([Bind("id,UsedAllowanceID")] Allowance allowance)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(allowance);

                    //allowance.ClientId = User.Identity.Name;
                    allowance.ClientId = "t1@test.com";
                    //allowance.DateTime = DateTime.Now;

                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            catch
             (DbUpdateException ex)
            {
                //Log the error (uncomment ex variable name and write a log.
                ModelState.AddModelError("", "Unable to save changes. " +
                    "Try again, and if the problem persists " +
                    "see your system administrator.");
            }

            return View(allowance);
        }



        // GET: Allowance/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var allowanceToUpdate = await _context.Allowance.SingleOrDefaultAsync(m => m.id == id);
            
            return View(allowanceToUpdate);

        }

        // POST: Allowance/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,UsedAllowanceID,AllowanceType,Description,PaidBy,Amount,Taxable,W1,PayrollTax,OTE,SGRule,SpecialSuperRule,SpecialSuperRate")] Allowance allowance)
        {
            if (id != allowance.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var allow = _context.Allowance.Where(b => b.id == allowance.id).FirstOrDefault();
                    allow.id = allowance.id;
                    _context.Update(allow);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AllowanceExists(allowance.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index");
            }
            return View(allowance);
        }


        // GET: Allowance/Delete/5
        public async Task<IActionResult> Delete(int? id, bool? saveChangesError = false)
        {


            if (id == null)
            {
                return NotFound();
            }

            var allowance = await _context.Allowance.AsNoTracking().SingleOrDefaultAsync(m => m.id == id);
            if (allowance == null)
            {
                return NotFound();
            }
            if (saveChangesError.GetValueOrDefault())
            {
                ViewData["ErrorMessage"] =
                    "Delete failed. Try again, and if the problem persists " +
                    "see your system administrator.";
            }



            return View(allowance);
        }

        // POST: Allowance/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var allowance = await _context.Allowance.AsNoTracking()
            .SingleOrDefaultAsync(m => m.id == id);
            if (allowance == null)
            {
                return RedirectToAction("Index");
            }

            try
            {

                _context.Allowance.Remove(allowance);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            catch (DbUpdateException /* ex */)
            {
                //Log the error (uncomment ex variable name and write a log.)
                return RedirectToAction("Delete", new { id = id, saveChangesError = true });
            }

        }

        private bool AllowanceExists(int id)
        {
            return _context.Allowance.Any(e => e.id == id);
        }
        public IActionResult DateTimePicker()
        {
            return View();
        }
    }
}
