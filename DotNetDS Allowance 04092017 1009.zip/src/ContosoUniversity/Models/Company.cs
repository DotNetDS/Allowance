﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class Company
    {
        public int id { get; set; }
        public string clientID { get; set; }
        public virtual string EmployerABN { get; set; }
        public virtual string EmployerWPN { get; set; }
        public virtual string EmployerTradingName { get; set; }
        public virtual string EmployerOrgName { get; set; }
        public virtual string EmployerBranchCode { get; set; }
        public virtual string EmployerBMSID { get; set; }
        public virtual string EmployerContactName { get; set; }
        public virtual string EmployerEmail { get; set; }
        public virtual string EmployerPhone { get; set; }
        public virtual string EmployerAddressLine1 { get; set; }
        public virtual string EmployerAddressLine2 { get; set; }
        public virtual string EmployerLocality { get; set; }
        public virtual int EmployerState { get; set; }
        public virtual string EmployerPostCode { get; set; }
        public virtual string IntermediaryABN { get; set; }
        public virtual string IntermediaryOrgName { get; set; }
        public virtual string IntermediaryRAN { get; set; }
        public virtual string IntermediaryBMSID { get; set; }
        public virtual string IntermediaryContactName { get; set; }
        public virtual string IntermediaryEmail { get; set; }
        public virtual string IntermediaryPhone { get; set; }
        public virtual string IntermediaryAddressLine1 { get; set; }
        public virtual string IntermediaryAddressLine2 { get; set; }
        public virtual string IntermediaryLocality { get; set; }
        public virtual int IntermediaryState { get; set; }
        public virtual string IntermediaryPostCode { get; set; }
        public virtual string SSSenderABN { get; set; }
        public virtual string SSSenderOrgName { get; set; }
        public virtual string SSSenderFamilyName { get; set; }
        public virtual string SSSenderGivenName { get; set; }
        public virtual string SSSenderOtherGivenName { get; set; }
        public virtual string SSSenderPosition { get; set; }
        public virtual string SSSenderEmail { get; set; }
        public virtual string SSSenderPhone { get; set; }
        public virtual string SSSenderEntityIDType { get; set; }
        public virtual string SSSenderElectronicServAddress { get; set; }
        public virtual Boolean SSSenderElectronicErrorMessage { get; set; }
        public virtual string SSReceiverABN { get; set; }
        public virtual string SSReceiverOrgName { get; set; }
        public virtual string SSPayerABN { get; set; }
        public virtual string SSPayerOrgName { get; set; }
        public virtual string SSPayerBSB { get; set; }
        public virtual string SSAccountNumber { get; set; }
        public virtual string SSAccountName { get; set; }
        public virtual string SSAccountBranchName { get; set; }
        public virtual int SSAccountBank { get; set; }
    }
}
