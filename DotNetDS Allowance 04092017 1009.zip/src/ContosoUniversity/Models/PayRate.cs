﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class PayRate
    {
        public int id { get; set; }
        public string clientID { get; set; }
        public virtual int UsedPayRateID { get; set; }
        public virtual string PayRateType { get; set; }
        public virtual string Description { get; set; }
        public virtual string PaidBy { get; set; }
        public virtual string Amount { get; set; }
        public virtual Boolean Taxable { get; set; }
        public virtual Boolean PayRollTax { get; set; }
        public virtual Boolean OTE { get; set; }
        public virtual Boolean SGRule { get; set; }
        public virtual Boolean SuperDeductBeforeTax { get; set; }
        public virtual Boolean SpecialSuperRule { get; set; }
        public virtual float SpecialSuperRate { get; set; }
        public virtual Boolean AL { get; set; }
        public virtual Boolean PL { get; set; }
        public virtual Boolean LSL { get; set; }
        public virtual Boolean RDO { get; set; }
        public virtual Boolean TIL { get; set; }
    }
}
