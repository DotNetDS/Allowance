﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class Deduction
    {
        public int id { get; set; }
        public string clientID { get; set; }
        public virtual int UsedDeductionID { get; set; }
        public virtual string DeductionType { get; set; }
        public virtual string Description { get; set; }
        public virtual string PaidBy { get; set; }
        public virtual Boolean Amount { get; set; }
        public virtual Boolean Super { get; set; }
        public virtual Boolean SuperReportToATO { get; set; }
        public virtual Boolean VariableDeduction { get; set; }
        public virtual Boolean SalarySac { get; set; }
        public virtual Boolean FBT { get; set; }
        public virtual string FBTFactor { get; set; }
        public virtual string FBTType { get; set; }
        public virtual Boolean OTEPercent { get; set; }
        public virtual Boolean Union { get; set; }
        public virtual Boolean WorkplaceGiving { get; set; }
    }
}
