﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class Allowance
    {
        //public int id { get; set; }
        //public string clientID { get; set; }
        //public virtual int UserAllowanceID { get; set; }
        //public virtual string AllowanceType { get; set; }
        //public virtual string Description { get; set; }
        //public virtual int PaidBy { get; set; }
        //public virtual string Amount { get; set; }
        //public virtual Boolean Taxable { get; set; }
        //public virtual Boolean W1 { get; set; }
        //public virtual Boolean PayrollTax { get; set; }
        //public virtual Boolean OTE { get; set; }
        //public virtual Boolean SGRule { get; set; }
        //public virtual Boolean SpecialSuperRule { get; set; }
        //public virtual float SpecialSuperRate { get; set; }

        public const int MaxClientIdLength = 50;
        public const int MaxUsedAllowanceIDLength = 10;
        public const int MaxAllowanceTypeLength = 2;
        public const int MaxDescriptionLength = 35;
        public const int MaxPaidByLength = 10;
        public const int MaxAmountLength = 10;
        public const int MaxTaxableLength = 4;
        public const int MaxW1Length = 4;
        public const int MaxPayrollTaxLength = 4;
        public const int MaxOTELength = 4;
        public const int MaxSGRuleLength = 4;
        public const int MaxSpecialSuperRuleLength = 4;
        public const int MaxSpecialSuperRateLength = 11;

        public int id { get; set; }
        //[Required]
        //[MaxLength(MaxClientIdLength)]
        public string ClientId { get; set; }
        //[Required]
        //[MaxLength(MaxUsedAllowanceIDLength)]
        public int UsedAllowanceID { get; set; }
        //[Required]
        //[MaxLength(MaxAllowanceTypeLength)]
        public string AllowanceType { get; set; }
        //[Required]
        //[MaxLength(MaxDescriptionLength)]
        public string Description { get; set; }
        //[Required]
        //[MaxLength(MaxAllowanceTypeLength)]
        public int PaidBy { get; set; }
        //[Required]
        //[MaxLength(MaxAmountLength)]
        public string Amount { get; set; }
        //[Required]
        //[MaxLength(MaxTaxableLength)]
        public Boolean Taxable { get; set; }
        //[Required]
        //[MaxLength(MaxW1Length)]
        public Boolean W1 { get; set; }
        //[Required]
        //[MaxLength(MaxPayrollTaxLength)]
        public Boolean PayrollTax { get; set; }
        //[Required]
        //[MaxLength(MaxOTELength)]
        public Boolean OTE { get; set; }
        //[Required]
        //[MaxLength(MaxSGRuleLength)]
        public Boolean SGRule { get; set; }
        //[Required]
        //[MaxLength(MaxSpecialSuperRuleLength)]
        public Boolean SpecialSuperRule { get; set; }
        //[Required]
        //[MaxLength(MaxSpecialSuperRateLength)]
        public float SpecialSuperRate { get; set; }
    }
}
